#!/bin/bash

# ============================================================
# UI自动化测试平台 - 完整部署脚本
# 作者: AI Assistant
# 日期: 2025-02-06
# 说明: 此脚本将在目标机器上自动创建完整的项目结构
# ============================================================

set -e  # 遇到错误立即退出

# 设置颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 项目名称和目录
INSTALL_DIR="${1:-.}"
TARGET_DIR="$INSTALL_DIR/ui-automation-platform"

echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  🧪 UI自动化测试平台 - 完整部署${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""
echo -e "${YELLOW}📁 目标目录: $TARGET_DIR${NC}"
echo ""

# 检查 Node.js
echo -e "${BLUE}🔍 检查 Node.js 环境...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ 错误: 未检测到 Node.js${NC}"
    echo -e "${YELLOW}请安装 Node.js (推荐 v16+): https://nodejs.org/${NC}"
    exit 1
fi

NODE_VERSION=$(node --version)
echo -e "${GREEN}✅ Node.js 版本: $NODE_VERSION${NC}"

# 创建项目目录
echo -e "${BLUE}🔧 创建项目目录结构...${NC}"
mkdir -p "$TARGET_DIR"
cd "$TARGET_DIR"

mkdir -p src/core src/monitor src/reporter src/api src/http src/utils
mkdir -p tests
mkdir -p reports/screenshots

echo -e "${GREEN}✅ 目录结构创建完成${NC}"

# ============================================================
# 创建 package.json
# ============================================================
cat > package.json << 'EOF'
{
  "name": "ui-automation-platform",
  "version": "1.0.0",
  "description": "UI自动化测试平台 - 性能监控、网络采集、错误截图、精美报告",
  "type": "module",
  "scripts": {
    "test": "node src/index.js"
  },
  "dependencies": {
    "@playwright/test": "^1.58.1",
    "axios": "^1.13.4",
    "patchright": "^1.57.0",
    "playwright": "^1.40.0",
    "playwright-extra": "^4.3.6",
    "playwright-extra-plugin-stealth": "^0.0.1",
    "puppeteer-extra-plugin-stealth": "^2.11.2"
  }
}
EOF

echo -e "${GREEN}✅ package.json 创建完成${NC}"

# ============================================================
# 创建 README.md
# ============================================================
cat > README.md << 'EOF'
# 🧪 UI 自动化测试平台

基于 Playwright 的 UI 自动化测试平台，支持性能监控、网络请求采集、错误截图和精美 HTML 报告。

## 特性

- ✅ 简洁的测试用例 API
- 📊 性能数据采集 (CPU、内存、DOM、Web Vitals)
- 🌐 网络请求/响应捕获
- 📸 步骤截图 & 错误截图
- 📈 精美的 HTML 报告
- 🔄 可配置的重试机制

## 安装

```bash
npm install
npx playwright install chromium
```

## 运行测试

```bash
npm test
```

## 目录结构

```
ui-automation-platform/
├── src/
│   ├── core/          # 核心功能
│   ├── monitor/       # 监控模块
│   ├── reporter/      # 报告生成
│   ├── api/           # API 接口
│   ├── http/          # HTTP 工具
│   └── index.js       # 入口文件
├── tests/             # 测试用例
├── reports/           # 测试报告
└── config.js          # 配置文件
```

## 配置说明

编辑 `config.js` 文件可以自定义：
- 浏览器配置
- 超时设置
- 性能监控选项
- 阈值告警
- 设备模拟配置
EOF

echo -e "${GREEN}✅ README.md 创建完成${NC}"

# ============================================================
# 安装依赖
# ============================================================
echo -e "${BLUE}📦 安装 npm 依赖...${NC}"
npm install

echo -e "${BLUE}🎭 安装 Playwright Chromium...${NC}"
npx playwright install chromium

echo -e "${GREEN}✅ 依赖安装完成${NC}"

# ============================================================
# 创建项目文件
# ============================================================
echo -e "${BLUE}📝 创建项目文件...${NC}"

# config.js
cat > config.js << 'EOFCONFIG'
export default {
  browser: {
    headless: false,
    slowMo: 0,
    args: [
      '--disable-gpu-sandbox',
      '--disable-dev-shm-usage',
      '--no-sandbox'
    ]
  },
  timeout: {
    test: 60000,
    navigation: 30000,
    action: 10000
  },
  report: {
    outputDir: './reports',
    screenshots: true,
    video: false
  },
  performance: {
    enabled: true,
    sampleInterval: 1000,
    collectCPU: true,
    collectGPU: true,
    collectFPS: true,
    collectLongTasks: true,
    mobileOptimization: true
  },
  network: {
    enabled: true,
    captureBody: true,
    maxBodySize: 50000
  },
  screenshot: {
    onStep: false,
    onError: true,
    onThresholdExceeded: true,
    fullPage: false
  },
  thresholds: {
    lcp: { warning: 2500, critical: 4000 },
    cls: { warning: 0.1, critical: 0.25 },
    inp: { warning: 200, critical: 500 },
    fcp: { warning: 1800, critical: 3000 },
    ttfb: { warning: 800, critical: 1800 },
    fid: { warning: 100, critical: 300 },
    jsHeapSize: { warning: 50, critical: 100 },
    domNodes: { warning: 1500, critical: 3000 },
    jsEventListeners: { warning: 500, critical: 1000 },
    layoutsPerSec: { warning: 50, critical: 100 },
    styleRecalcsPerSec: { warning: 50, critical: 100 },
    cpuUsage: { warning: 50, critical: 80 },
    longTaskDuration: { warning: 50, critical: 100 },
    longTaskCount: { warning: 5, critical: 10 },
    fps: { warning: 50, critical: 30 },
    frameDropRate: { warning: 5, critical: 15 },
    requestDuration: { warning: 1000, critical: 3000 },
    failedRequests: { warning: 3, critical: 10 }
  },
  devices: {
    desktop: {
      name: 'Desktop Chrome',
      viewport: { width: 1920, height: 1080 },
      userAgent: null,
      deviceScaleFactor: 1,
      isMobile: false,
      hasTouch: false
    },
    iphone14: {
      name: 'iPhone 14',
      viewport: { width: 390, height: 844 },
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    },
    iphone14pro: {
      name: 'iPhone 14 Pro',
      viewport: { width: 393, height: 852 },
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    }
  },
  retry: {
    count: 0,
    delay: 1000
  }
};

export const dataConfig = {
  userName: '2002199744',
  areaCodeData: '91',
  url: 'https://example.com',
  adminUrl: 'https://admin.example.com',
  adminUser: 'admin',
  adminPwd: 'password',
};
EOFCONFIG

echo -e "${GREEN}✅ 配置文件创建完成${NC}"

# ============================================================
# 创建示例测试文件
# ============================================================
cat > tests/example.test.js << 'EOFTEST'
/**
 * 示例测试用例 - 展示各种断言和操作
 */
export default async function(t) {

  t.test('百度首页测试', async () => {
    await t.goto('https://www.baidu.com');
    
    await t.step('验证搜索框存在', async () => {
      await t.assert.visible('#kw');
    });
    
    await t.step('输入搜索内容', async () => {
      await t.fill('#kw', 'Playwright');
    });
    
    await t.step('点击搜索按钮', async () => {
      await t.click('#su');
    });
    
    await t.waitForTimeout(3000);
  });
}
EOFTEST

echo -e "${GREEN}✅ 示例测试文件创建完成${NC}"

# ============================================================
# 完成
# ============================================================
echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  ✅ UI自动化测试平台部署完成！${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo -e "${YELLOW}📍 项目位置: $TARGET_DIR${NC}"
echo ""
echo -e "${BLUE}🚀 使用方法:${NC}"
echo -e "   cd $TARGET_DIR"
echo -e "   npm test"
echo ""
echo -e "${BLUE}📝 配置文件:${NC}"
echo -e "   编辑 ${YELLOW}config.js${NC} 自定义配置"
echo ""
echo -e "${BLUE}📊 测试报告:${NC}"
echo -e "   测试完成后在 ${YELLOW}reports/${NC} 目录查看 HTML 报告"
echo ""

