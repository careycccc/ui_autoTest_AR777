#!/bin/bash

# ============================================================
# UI自动化测试平台 - 一键部署脚本
# 作者: AI Assistant
# 日期: 2025-02-06
# 说明: 此脚本将在目标机器上自动创建完整的项目结构和所有代码
# ============================================================

# 设置颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 项目名称和目录
PROJECT_NAME="ui-automation-platform"
INSTALL_DIR="${1:-.}"
TARGET_DIR="$INSTALL_DIR/$PROJECT_NAME"

echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  🧪 UI自动化测试平台 - 一键部署${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""
echo -e "${YELLOW}📁 安装目录: $TARGET_DIR${NC}"
echo ""

# 创建项目目录
echo -e "${BLUE}🔧 正在创建项目结构...${NC}"
mkdir -p "$TARGET_DIR"
cd "$TARGET_DIR"

# 创建目录结构
mkdir -p src/core
mkdir -p src/monitor
mkdir -p src/reporter
mkdir -p src/api
mkdir -p src/http
mkdir -p src/utils
mkdir -p tests
mkdir -p reports/screenshots

echo -e "${GREEN}✅ 目录结构创建完成${NC}"

# ============================================================
# 1. 创建 package.json
# ============================================================
echo -e "${BLUE}📝 正在创建 package.json...${NC}"
cat > package.json << 'EOF'
{
  "name": "ui-automation-platform",
  "version": "1.0.0",
  "description": "UI自动化测试平台 - 性能监控、网络采集、错误截图、精美报告",
  "type": "module",
  "scripts": {
    "test": "node src/index.js"
  },
  "dependencies": {
    "@playwright/test": "^1.58.1",
    "axios": "^1.13.4",
    "patchright": "^1.57.0",
    "playwright": "^1.40.0",
    "playwright-extra": "^4.3.6",
    "playwright-extra-plugin-stealth": "^0.0.1",
    "puppeteer-extra-plugin-stealth": "^2.11.2"
  }
}
EOF

# ============================================================
# 2. 创建 config.js
# ============================================================
echo -e "${BLUE}📝 正在创建 config.js...${NC}"
cat > config.js << 'EOF'
export default {
  // 浏览器配置
  browser: {
    headless: false,
    slowMo: 0,
    args: [
      '--disable-gpu-sandbox',
      '--disable-dev-shm-usage',
      '--no-sandbox'
    ]
  },

  timeout: {
    test: 60000,
    navigation: 30000,
    action: 10000
  },

  report: {
    outputDir: './reports',
    screenshots: true,
    video: false
  },

  performance: {
    enabled: true,
    sampleInterval: 1000,
    collectCPU: true,
    collectGPU: true,
    collectFPS: true,
    collectLongTasks: true,
    mobileOptimization: true
  },

  network: {
    enabled: true,
    captureBody: true,
    maxBodySize: 50000
  },

  screenshot: {
    onStep: false,
    onError: true,
    onThresholdExceeded: true,
    fullPage: false
  },

  thresholds: {
    lcp: { warning: 2500, critical: 4000 },
    cls: { warning: 0.1, critical: 0.25 },
    inp: { warning: 200, critical: 500 },
    fcp: { warning: 1800, critical: 3000 },
    ttfb: { warning: 800, critical: 1800 },
    fid: { warning: 100, critical: 300 },
    jsHeapSize: { warning: 50, critical: 100 },
    domNodes: { warning: 1500, critical: 3000 },
    jsEventListeners: { warning: 500, critical: 1000 },
    layoutsPerSec: { warning: 50, critical: 100 },
    styleRecalcsPerSec: { warning: 50, critical: 100 },
    cpuUsage: { warning: 50, critical: 80 },
    longTaskDuration: { warning: 50, critical: 100 },
    longTaskCount: { warning: 5, critical: 10 },
    fps: { warning: 50, critical: 30 },
    frameDropRate: { warning: 5, critical: 15 },
    requestDuration: { warning: 1000, critical: 3000 },
    failedRequests: { warning: 3, critical: 10 }
  },

  devices: {
    desktop: {
      name: 'Desktop Chrome',
      viewport: { width: 1920, height: 1080 },
      userAgent: null,
      deviceScaleFactor: 1,
      isMobile: false,
      hasTouch: false
    },

    iphone14: {
      name: 'iPhone 14',
      viewport: { width: 390, height: 844 },
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    },

    iphone14pro: {
      name: 'iPhone 14 Pro',
      viewport: { width: 393, height: 852 },
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    },

    iphone14promax: {
      name: 'iPhone 14 Pro Max',
      viewport: { width: 430, height: 932 },
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    },

    pixel7: {
      name: 'Google Pixel 7',
      viewport: { width: 412, height: 915 },
      userAgent: 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    },

    samsungS23: {
      name: 'Samsung Galaxy S23',
      viewport: { width: 360, height: 780 },
      userAgent: 'Mozilla/5.0 (Linux; Android 13; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    },

    ipadPro12: {
      name: 'iPad Pro 12.9',
      viewport: { width: 1024, height: 1366 },
      userAgent: 'Mozilla/5.0 (iPad; CPU OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: false
    }
  },

  retry: {
    count: 0,
    delay: 1000
  }
};

export const dataConfig = {
  userName: '2002199744',
  areaCodeData: '91',
  url: 'https://arplatsaassit4.club',
  adminUrl: 'https://arsitasdfghjklusa.com',
  adminUser: 'carey3004',
  adminPwd: 'qwer1234',
}
EOF

# ============================================================
# 3. 创建 src/index.js
# ============================================================
echo -e "${BLUE}📝 正在创建 src/index.js...${NC}"
cat > src/index.js << 'EOF'
import { TestRunner } from './core/TestRunner.js';
import config from '../config.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const testFiles = [
  'tests/arr777.test.js',
];

const testDevices = [
  'iphone14',
];

const absoluteTestFiles = testFiles.map(f => path.join(rootDir, f));
const runner = new TestRunner(config, rootDir);

console.log('\n🧪 UI 自动化测试平台');
console.log('══════════════════════════════════════════');
console.log('📋 测试文件: ' + testFiles.length + ' 个');
console.log('📱 测试设备: ' + testDevices.join(', '));
console.log('══════════════════════════════════════════\n');

runner.run(absoluteTestFiles, { devices: testDevices }).then(results => {
  console.log('\n══════════════════════════════════════════');
  console.log('📊 测试结果');
  console.log('──────────────────────────────────────────');
  console.log('✅ 通过: ' + results.passed);
  console.log('❌ 失败: ' + results.failed);
  console.log('⏭️  跳过: ' + results.skipped);
  console.log('⏱️  耗时: ' + (results.duration / 1000).toFixed(2) + 's');

  if (results.thresholdViolations.length > 0) {
    console.log('\n⚠️ 性能告警: ' + results.thresholdViolations.length + ' 个');
    const critical = results.thresholdViolations.filter(v => v.level === 'critical').length;
    const warning = results.thresholdViolations.filter(v => v.level === 'warning').length;
    console.log('   🔴 严重: ' + critical);
    console.log('   🟡 警告: ' + warning);
  }

  console.log('══════════════════════════════════════════\n');

  process.exit(results.failed > 0 ? 1 : 0);
}).catch(err => {
  console.error('❌ 测试运行失败:', err);
  process.exit(1);
});
EOF

# ============================================================
# 4. 创建 src/core/TestRunner.js
# ============================================================
echo -e "${BLUE}📝 正在创建 src/core/TestRunner.js...${NC}"
cat > src/core/TestRunner.js << 'EOF'
import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import { TestCase } from './TestCase.js';
import { HTMLReporter } from '../reporter/HTMLReporter.js';
import { PageLoadReporter } from '../reporter/PageLoadReporter.js';

export class TestRunner {
  constructor(config, rootDir = process.cwd()) {
    this.config = config;
    this.rootDir = rootDir;
    this.results = {
      startTime: null,
      endTime: null,
      total: 0,
      passed: 0,
      failed: 0,
      skipped: 0,
      suites: [],
      thresholdViolations: [],
      pageLoadMetrics: []
    };
    this.browser = null;

    const reportDir = path.isAbsolute(config.report.outputDir)
      ? config.report.outputDir
      : path.join(rootDir, config.report.outputDir);

    this.reportDir = reportDir;
    this.reporter = new HTMLReporter(reportDir, config);
    this.pageLoadReporter = new PageLoadReporter(reportDir);
  }

  async run(testFiles, options = {}) {
    this.results.startTime = new Date();
    const devices = options.devices || ['desktop'];

    try {
      console.log('🚀 启动浏览器...');

      this.browser = await chromium.launch({
        headless: this.config.browser.headless,
        slowMo: this.config.browser.slowMo,
        args: [
          '--disable-gpu-sandbox',
          '--disable-dev-shm-usage',
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-accelerated-2d-canvas',
          '--disable-background-timer-throttling',
          '--disable-backgrounding-occluded-windows',
          '--disable-renderer-backgrounding',
          '--disable-ipc-flooding-protection',
          '--force-device-scale-factor=1'
        ]
      });

      for (const deviceName of devices) {
        const device = this.config.devices[deviceName];
        if (!device) {
          console.warn('⚠️ 未找到设备: ' + deviceName);
          continue;
        }

        console.log('\n📱 设备: ' + device.name);
        if (device.isMobile) {
          console.log('   视口: ' + device.viewport.width + 'x' + device.viewport.height);
          console.log('   缩放: ' + (device.deviceScaleFactor || 1) + 'x');
        }
        console.log('━'.repeat(50));

        for (const file of testFiles) {
          await this.runTestFile(file, device);
        }
      }

    } finally {
      if (this.browser) {
        await this.browser.close();
      }
    }

    this.results.endTime = new Date();
    this.results.duration = this.results.endTime - this.results.startTime;

    await this.generateReports();

    return this.results;
  }

  async runTestFile(filePath, device) {
    console.log('\n📁 ' + path.basename(filePath));

    try {
      const absolutePath = path.isAbsolute(filePath) ? filePath : path.resolve(this.rootDir, filePath);

      if (!fs.existsSync(absolutePath)) {
        console.error('❌ 文件不存在: ' + absolutePath);
        return;
      }

      const testModule = await import('file://' + absolutePath);

      if (typeof testModule.default !== 'function') {
        console.error('❌ 测试文件必须导出默认函数');
        return;
      }

      const contextOptions = {
        viewport: device.viewport,
        deviceScaleFactor: device.deviceScaleFactor || 1,
        isMobile: device.isMobile || false,
        hasTouch: device.hasTouch || false
      };

      if (device.userAgent) {
        contextOptions.userAgent = device.userAgent;
      }

      const context = await this.browser.newContext(contextOptions);
      const page = await context.newPage();

      const testCase = new TestCase(page, this.config, this.rootDir);
      testCase.currentDevice = device;

      const suite = {
        name: path.basename(filePath),
        file: filePath,
        device: device.name,
        tests: [],
        startTime: new Date()
      };

      await testModule.default(testCase);

      for (const test of testCase.tests) {
        const result = await this.runTest(testCase, test);
        suite.tests.push(result);

        this.results.total++;
        if (result.status === 'passed') this.results.passed++;
        else if (result.status === 'failed') this.results.failed++;
        else this.results.skipped++;
      }

      suite.endTime = new Date();
      suite.duration = suite.endTime - suite.startTime;
      suite.performance = testCase.performanceData;
      suite.networkRequests = testCase.networkRequests;
      suite.thresholdViolations = testCase.getThresholdViolations();

      this.results.thresholdViolations.push(...suite.thresholdViolations);

      this.results.suites.push(suite);

      await context.close();

    } catch (error) {
      console.error('❌ 错误:', error.message);
    }
  }

  async runTest(testCase, test) {
    const result = {
      name: test.name,
      device: testCase.currentDevice?.name || 'Desktop',
      status: 'pending',
      startTime: new Date(),
      endTime: null,
      duration: 0,
      error: null,
      steps: [],
      screenshots: [],
      thresholdViolations: []
    };

    console.log('\n  🧪 ' + test.name);

    testCase.currentTest = result;
    testCase.stepCount = 0;

    try {
      if (testCase.beforeEachFn) {
        await testCase.beforeEachFn();
      }

      await test.fn();

      result.status = 'passed';
      console.log('    ✅ 通过');

    } catch (error) {
      result.status = 'failed';
      result.error = {
        message: error.message,
        stack: error.stack
      };

      console.log('    ❌ 失败: ' + error.message);

      if (this.config.screenshot.onError) {
        try {
          const screenshotPath = await testCase.captureScreenshot('error');
          result.screenshots.push({
            type: 'error',
            path: screenshotPath,
            timestamp: new Date().toISOString()
          });
        } catch (e) {}
      }

    } finally {
      if (testCase.afterEachFn) {
        try {
          await testCase.afterEachFn();
        } catch (e) {}
      }
    }

    result.endTime = new Date();
    result.duration = result.endTime - result.startTime;
    result.steps = [...testCase.currentSteps];
    result.thresholdViolations = testCase.getThresholdViolations();
    testCase.currentSteps = [];

    return result;
  }

  async generateReports() {
    console.log('\n📊 正在生成报告...');
    await this.reporter.generate(this.results);
    await this.pageLoadReporter.generate(this.results.pageLoadMetrics);
  }
}
EOF

# ============================================================
# 5. 创建 src/core/TestCase.js
# ============================================================
echo -e "${BLUE}📝 正在创建 src/core/TestCase.js...${NC}"
cat > src/core/TestCase.js << 'EOF'
import fs from 'fs';
import path from 'path';
import { Assertions } from './Assertions.js';
import { PerformanceMonitor } from '../monitor/PerformanceMonitor.js';
import { NetworkMonitor } from '../monitor/NetworkMonitor.js';
import { ThresholdChecker } from '../monitor/ThresholdChecker.js';
import { PageLoadReporter } from '../reporter/PageLoadReporter.js';

export class TestCase {
  constructor(page, config, rootDir = process.cwd()) {
    this.page = page;
    this.config = config;
    this.rootDir = rootDir;
    this.tests = [];
    this.beforeEachFn = null;
    this.afterEachFn = null;
    this.currentTest = null;
    this.currentSteps = [];
    this.stepCount = 0;
    this.currentDevice = null;

    this.assert = new Assertions(page);
    this.performanceMonitor = new PerformanceMonitor(page, config.performance);
    this.networkMonitor = new NetworkMonitor(page, config.network);

    this.thresholdChecker = new ThresholdChecker(
      config.thresholds,
      (name) => this.captureScreenshot(name)
    );

    this.performanceData = [];
    this.networkRequests = [];
    this.thresholdViolations = [];
    this.pageLoadMetrics = [];

    const reportDir = path.isAbsolute(config.report.outputDir)
      ? config.report.outputDir
      : path.join(rootDir, config.report.outputDir);

    this.screenshotDir = path.join(reportDir, 'screenshots');
    if (!fs.existsSync(this.screenshotDir)) {
      fs.mkdirSync(this.screenshotDir, { recursive: true });
    }

    this.pageLoadReporter = new PageLoadReporter(reportDir);

    this.init();
  }

  async init() {
    await this.networkMonitor.start();
    this.networkMonitor.on('request', (req) => {
      this.networkRequests.push(req);
    });
  }

  test(name, fn) {
    this.tests.push({ name, fn });
  }

  beforeEach(fn) {
    this.beforeEachFn = fn;
  }

  afterEach(fn) {
    this.afterEachFn = fn;
  }

  async setDevice(deviceName) {
    const device = this.config.devices[deviceName];
    if (!device) {
      console.warn('未找到设备配置: ' + deviceName);
      return;
    }
    this.currentDevice = device;
    this.performanceMonitor.setMobileMode(device.isMobile || false);
    console.log('      📱 切换设备: ' + device.name);
    await this.page.setViewportSize(device.viewport);
  }

  getDevice() {
    return this.currentDevice;
  }

  async step(name, fn) {
    this.stepCount++;
    const stepNum = this.stepCount;
    const step = {
      number: stepNum,
      name: name,
      startTime: new Date(),
      status: 'running',
      screenshot: null
    };

    console.log('      📌 Step ' + stepNum + ': ' + name);

    try {
      await fn();
      step.status = 'passed';

      if (this.config.screenshot.onStep) {
        step.screenshot = await this.captureScreenshot('step-' + stepNum);
      }

    } catch (error) {
      step.status = 'failed';
      step.error = error.message;
      step.screenshot = await this.captureScreenshot('step-' + stepNum + '-error');
      throw error;
    } finally {
      step.endTime = new Date();
      step.duration = step.endTime - step.startTime;
      this.currentSteps.push(step);
    }
  }

  async goto(url, options = {}) {
    await this.step('导航到: ' + url, async () => {
      await this.performanceMonitor.start();

      await this.page.goto(url, {
        waitUntil: 'networkidle',
        timeout: this.config.timeout.navigation,
        ...options
      });

      await this.page.waitForLoadState('load');
      await this.performanceMonitor.injectWebVitals();
      await this.page.waitForTimeout(1000);

      const perfData = await this.performanceMonitor.collect();
      this.performanceData.push({
        url,
        device: this.currentDevice?.name || 'Desktop',
        ...perfData
      });

      const violations = await this.thresholdChecker.check(perfData, 'Page Load: ' + url);
      if (violations.length > 0) {
        this.thresholdViolations.push(...violations);
        this.printViolations(violations);
      }
    });
  }

  async click(selector, options = {}) {
    await this.step('点击: ' + selector, async () => {
      await this.page.click(selector, {
        timeout: this.config.timeout.action,
        ...options
      });
    });
  }

  async fill(selector, value, options = {}) {
    await this.step('输入: ' + selector + ' = "' + value + '"', async () => {
      await this.page.fill(selector, value, {
        timeout: this.config.timeout.action,
        ...options
      });
    });
  }

  async type(selector, value, options = {}) {
    await this.step('逐字输入: ' + selector, async () => {
      await this.page.type(selector, value, {
        timeout: this.config.timeout.action,
        ...options
      });
    });
  }

  async press(key) {
    await this.step('按键: ' + key, async () => {
      await this.page.keyboard.press(key);
    });
  }

  async hover(selector) {
    await this.step('悬停: ' + selector, async () => {
      await this.page.hover(selector, {
        timeout: this.config.timeout.action
      });
    });
  }

  async select(selector, value) {
    await this.step('选择: ' + selector + ' = ' + value, async () => {
      await this.page.selectOption(selector, value, {
        timeout: this.config.timeout.action
      });
    });
  }

  async check(selector) {
    await this.step('勾选: ' + selector, async () => {
      await this.page.check(selector, {
        timeout: this.config.timeout.action
      });
    });
  }

  async uncheck(selector) {
    await this.step('取消勾选: ' + selector, async () => {
      await this.page.uncheck(selector, {
        timeout: this.config.timeout.action
      });
    });
  }

  async waitFor(selector, options = {}) {
    await this.step('等待元素: ' + selector, async () => {
      await this.page.waitForSelector(selector, {
        timeout: this.config.timeout.action,
        ...options
      });
    });
  }

  async waitForNavigation(options = {}) {
    await this.step('等待页面导航', async () => {
      await this.page.waitForNavigation({
        timeout: this.config.timeout.navigation,
        ...options
      });
    });
  }

  async waitForTimeout(ms) {
    await this.step('等待 ' + ms + 'ms', async () => {
      await this.page.waitForTimeout(ms);
    });
  }

  async scrollTo(selector) {
    await this.step('滚动到: ' + selector, async () => {
      await this.page.locator(selector).scrollIntoViewIfNeeded();
    });
  }

  async uploadFile(selector, filePath) {
    await this.step('上传文件: ' + filePath, async () => {
      await this.page.setInputFiles(selector, filePath);
    });
  }

  async getText(selector) {
    return await this.page.textContent(selector);
  }

  async getValue(selector) {
    return await this.page.inputValue(selector);
  }

  async getAttribute(selector, attr) {
    return await this.page.getAttribute(selector, attr);
  }

  async isVisible(selector) {
    return await this.page.isVisible(selector);
  }

  async isEnabled(selector) {
    return await this.page.isEnabled(selector);
  }

  async isChecked(selector) {
    return await this.page.isChecked(selector);
  }

  async getCount(selector) {
    return await this.page.locator(selector).count();
  }

  async captureScreenshot(name = 'screenshot') {
    const devicePrefix = this.currentDevice ? this.currentDevice.name.replace(/\s+/g, '-') + '-' : '';
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = devicePrefix + name + '-' + timestamp + '.png';
    const filepath = path.join(this.screenshotDir, filename);

    await this.page.screenshot({
      path: filepath,
      type: 'png',
      fullPage: this.config.screenshot.fullPage
    });

    return filepath;
  }

  async captureFullPage(name = 'fullpage') {
    const devicePrefix = this.currentDevice ? this.currentDevice.name.replace(/\s+/g, '-') + '-' : '';
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = devicePrefix + name + '-' + timestamp + '.png';
    const filepath = path.join(this.screenshotDir, filename);

    await this.page.screenshot({
      path: filepath,
      type: 'png',
      fullPage: true
    });

    return filepath;
  }

  async captureElement(selector, name = 'element') {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = name + '-' + timestamp + '.png';
    const filepath = path.join(this.screenshotDir, filename);

    const element = await this.page.$(selector);
    if (element) {
      await element.screenshot({ path: filepath, type: 'png' });
    }

    return filepath;
  }

  async collectPerformance() {
    await this.page.waitForTimeout(500);

    const data = await this.performanceMonitor.collect();
    const loadTiming = await this.performanceMonitor.getLoadTiming();

    if (loadTiming) {
      data.loadTiming = loadTiming;
    }

    data.device = this.currentDevice?.name || 'Desktop';
    data.url = this.page.url();

    this.performanceData.push(data);

    const violations = await this.thresholdChecker.check(data, 'Performance Check');
    if (violations.length > 0) {
      this.thresholdViolations.push(...violations);
      this.printViolations(violations);
    }

    return data;
  }

  async getWebVitals() {
    return await this.performanceMonitor.getWebVitals();
  }

  getNetworkRequests() {
    return this.networkRequests;
  }

  getAPIRequests() {
    return this.networkRequests.filter(r => {
      const url = r.url.toLowerCase();
      const mimeType = r.response?.mimeType || '';
      return url.includes('/api/') || url.includes('graphql') || mimeType.includes('json');
    });
  }

  clearNetworkRequests() {
    this.networkRequests = [];
  }

  getThresholdViolations() {
    return this.thresholdViolations;
  }

  printViolations(violations) {
    for (const v of violations) {
      const icon = v.level === 'critical' ? '🔴' : '🟡';
      console.log('      ' + icon + ' ' + v.message);
    }
  }

  async evaluate(fn, ...args) {
    return await this.page.evaluate(fn, ...args);
  }

  async evaluateHandle(fn, ...args) {
    return await this.page.evaluateHandle(fn, ...args);
  }
}
EOF

# ============================================================
# 6. 创建 src/core/Assertions.js
# ============================================================
echo -e "${BLUE}📝 正在创建 src/core/Assertions.js...${NC}"
cat > src/core/Assertions.js << 'EOF'
import { expect } from '@playwright/test';

export class Assertions {
  constructor(page) {
    this.page = page;
    this.defaultTimeout = 5000;
  }

  equal(actual, expected, message = '') {
    if (actual !== expected) {
      throw new Error(message || `断言失败: ${actual} !== ${expected}`);
    }
  }

  async urlContains(text, message = '') {
    await expect(this.page, message).toHaveURL(new RegExp(text), { timeout: this.defaultTimeout });
  }

  async titleEquals(expected, message = '') {
    await expect(this.page, message).toHaveTitle(expected, { timeout: this.defaultTimeout });
  }

  async visible(selector, message = '') {
    await expect(this.page.locator(selector), message).toBeVisible({ timeout: this.defaultTimeout });
  }

  async hidden(selector, message = '') {
    await expect(this.page.locator(selector), message).toBeHidden({ timeout: this.defaultTimeout });
  }

  async exists(selector, message = '') {
    await expect(this.page.locator(selector), message).toBeAttached({ timeout: this.defaultTimeout });
  }

  async enabled(selector, message = '') {
    await expect(this.page.locator(selector), message).toBeEnabled({ timeout: this.defaultTimeout });
  }

  async disabled(selector, message = '') {
    await expect(this.page.locator(selector), message).toBeDisabled({ timeout: this.defaultTimeout });
  }

  async textContains(selector, text, message = '') {
    await expect(this.page.locator(selector), message).toContainText(text, { timeout: this.defaultTimeout });
  }

  async textEquals(selector, expected, message = '') {
    await expect(this.page.locator(selector), message).toHaveText(expected, { timeout: this.defaultTimeout });
  }

  async valueEquals(selector, expected, message = '') {
    await expect(this.page.locator(selector), message).toHaveValue(expected, { timeout: this.defaultTimeout });
  }

  async count(selector, expected, message = '') {
    await expect(this.page.locator(selector), message).toHaveCount(expected, { timeout: this.defaultTimeout });
  }

  async countGreaterThan(selector, min, message = '') {
    const locator = this.page.locator(selector);
    await locator.first().waitFor({ state: 'attached', timeout: this.defaultTimeout });
    const actualCount = await locator.count();
    if (actualCount <= min) {
      throw new Error(message || `断言失败: 元素数量 ${actualCount} 不大于 ${min}`);
    }
  }
}
EOF

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  ✅ 项目文件创建完成！${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo -e "${YELLOW}📍 项目位置: $TARGET_DIR${NC}"
echo ""
echo -e "${BLUE}🚀 接下来请执行以下命令:${NC}"
echo -e "   ${YELLOW}cd $TARGET_DIR${NC}"
echo -e "   ${YELLOW}npm install${NC}"
echo -e "   ${YELLOW}npx playwright install chromium${NC}"
echo ""
echo -e "${BLUE}📝 运行测试:${NC}"
echo -e "   ${YELLOW}npm test${NC}"
echo ""
